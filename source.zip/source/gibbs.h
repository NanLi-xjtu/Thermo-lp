#ifndef GIBBS_H
#define GIBBS_H

#include "main.h"
int Gibbs();
void ReadINPUT ();

#endif
